/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.os.telas;

import java.sql.*;
import com.os.dal.ModuloConexao;
import javax.swing.JOptionPane;

/**
 *
 * @author Computador
 */
public class TelaUsuario extends javax.swing.JInternalFrame {

    Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    /**
     * Creates new form TelaUsuario
     */
    public TelaUsuario() {
        initComponents();
        conexao = ModuloConexao.conector();
    }

    private void consultar() {
        String sql = "select * from tbusuarios where iduser=?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtusuid.getText());
            rs = pst.executeQuery();
            if (rs.next()) {
                txtusunome.setText(rs.getString(2));
                txtusufone.setText(rs.getString(3));
                txtusuusu.setText(rs.getString(4));
                txtususenha.setText(rs.getString(5));
                cbousuperfil.setSelectedItem(rs.getString(6));
            } else {
                JOptionPane.showMessageDialog(null, "Usuario não cadastrado!");
                txtusuid.setText(null);
                txtusunome.setText(null);
                txtusufone.setText(null);
                txtusuusu.setText(null);
                txtususenha.setText(null);

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    private void adicionar() {
        String sql = "insert into tbusuarios (iduser,usuario,fone,login,senha,perfil) values (?,?,?,?,?,?)";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtusuid.getText());
            pst.setString(2, txtusunome.getText());
            pst.setString(3, txtusufone.getText());
            pst.setString(4, txtusuusu.getText());
            pst.setString(5, txtususenha.getText());
            pst.setString(6, cbousuperfil.getSelectedItem().toString());

            if ((txtusuid.getText().isEmpty())||(txtusunome.getText().isEmpty()) || (txtusuusu.getText().isEmpty()) || (txtususenha.getText().isEmpty())) {
                JOptionPane.showMessageDialog(null, "Preencha os campos obrigatórios");
            } else {

                int adicionado = pst.executeUpdate();
                if (adicionado > 0) {
                    JOptionPane.showMessageDialog(null, "Usuário adicionado com sucesso!");
                    txtusuid.setText(null);
                    txtusunome.setText(null);
                    txtusufone.setText(null);
                    txtusuusu.setText(null);
                    txtususenha.setText(null);

                } else {
                    JOptionPane.showMessageDialog(null, "Usuario não cadastrado!");
                    txtusuid.setText(null);
                    txtusunome.setText(null);
                    txtusufone.setText(null);
                    txtusuusu.setText(null);
                    txtususenha.setText(null);

                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    private void alterar() {
        String sql = "update tbusuarios set usuario=?,fone=?,login=?,senha=?,perfil=? where iduser=?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtusunome.getText());
            pst.setString(2, txtusufone.getText());
            pst.setString(3, txtusuusu.getText());
            pst.setString(4, txtususenha.getText());
            pst.setString(5, cbousuperfil.getSelectedItem().toString());
            pst.setString(6, txtusuid.getText());

            if ((txtusunome.getText().isEmpty()) || (txtusuusu.getText().isEmpty()) || (txtususenha.getText().isEmpty())) {
                JOptionPane.showMessageDialog(null, "Preencha os campos obrigatórios");
            } else {
                int atualizado = pst.executeUpdate();

                if (atualizado > 0) {
                    JOptionPane.showMessageDialog(null, "Usuário atualizado com sucesso!");
                    txtusuid.setText(null);
                    txtusunome.setText(null);
                    txtusufone.setText(null);
                    txtusuusu.setText(null);
                    txtususenha.setText(null);

                } else {
                    JOptionPane.showMessageDialog(null, "Usuario não atualizado");
                    txtusuid.setText(null);
                    txtusunome.setText(null);
                    txtusufone.setText(null);
                    txtusuusu.setText(null);
                    txtususenha.setText(null);
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    private void deletar(){
        int confirma = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja deletar o usuário?","Atenção",JOptionPane.YES_NO_OPTION);
        
        if (confirma == JOptionPane.YES_OPTION){
            String sql = "delete from tbusuarios where iduser=?";
            try {
                pst = conexao.prepareStatement(sql);
                pst.setString(1, txtusuid.getText());
                int apagado = pst.executeUpdate();
                if(apagado>0){
                    JOptionPane.showMessageDialog(null, "Usuário removido com sucesso!");
                    txtusuid.setText(null);
                    txtusunome.setText(null);
                    txtusufone.setText(null);
                    txtusuusu.setText(null);
                    txtususenha.setText(null);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        txtusunome = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtusufone = new javax.swing.JFormattedTextField();
        jLabel4 = new javax.swing.JLabel();
        txtusuusu = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtususenha = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        cbousuperfil = new javax.swing.JComboBox<>();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        btnusucreat = new javax.swing.JButton();
        btnusuread = new javax.swing.JButton();
        btnusuupdate = new javax.swing.JButton();
        btnusudelete = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtusuid = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();

        setClosable(true);
        setIconifiable(true);
        setTitle("Usuários");
        setMinimumSize(new java.awt.Dimension(650, 440));
        setPreferredSize(new java.awt.Dimension(650, 440));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setText("Cadastro de Usuarios");

        jLabel2.setText("*Nome:");

        jLabel3.setText("Telefone:");

        jLabel4.setText("*Usuario:");

        jLabel5.setText("*Senha:");

        txtususenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtususenhaActionPerformed(evt);
            }
        });

        jLabel6.setText("Perfil:");

        cbousuperfil.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "admin", "user" }));

        btnusucreat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/os/icon/creat.png"))); // NOI18N
        btnusucreat.setToolTipText("Adicionar");
        btnusucreat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnusucreat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnusucreatActionPerformed(evt);
            }
        });

        btnusuread.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/os/icon/read.png"))); // NOI18N
        btnusuread.setToolTipText("Consultar");
        btnusuread.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnusuread.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnusureadActionPerformed(evt);
            }
        });

        btnusuupdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/os/icon/update.png"))); // NOI18N
        btnusuupdate.setToolTipText("Editar");
        btnusuupdate.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnusuupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnusuupdateActionPerformed(evt);
            }
        });

        btnusudelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/os/icon/delete.png"))); // NOI18N
        btnusudelete.setToolTipText("Apagar");
        btnusudelete.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnusudelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnusudeleteActionPerformed(evt);
            }
        });

        jLabel7.setText("*ID:");

        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("* Campos obrigatórios");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jSeparator2)
                            .addComponent(jSeparator1)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtusuusu))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel7))
                                        .addGap(27, 27, 27)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtusuid, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtusunome, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel5))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jLabel8))
                                    .addComponent(txtususenha)
                                    .addComponent(txtusufone)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(36, 36, 36)
                                        .addComponent(cbousuperfil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel1))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(btnusucreat, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(90, 90, 90)
                        .addComponent(btnusuread, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(90, 90, 90)
                        .addComponent(btnusuupdate, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(90, 90, 90)
                        .addComponent(btnusudelete)
                        .addGap(27, 27, 27))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtusuid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtusunome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(txtusufone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtusuusu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtususenha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(cbousuperfil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnusucreat)
                    .addComponent(btnusuread)
                    .addComponent(btnusuupdate)
                    .addComponent(btnusudelete))
                .addContainerGap())
        );

        setBounds(0, 0, 650, 440);
    }// </editor-fold>//GEN-END:initComponents

    private void txtususenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtususenhaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtususenhaActionPerformed

    private void btnusureadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnusureadActionPerformed
        // TODO add your handling code here:
        consultar();
    }//GEN-LAST:event_btnusureadActionPerformed

    private void btnusucreatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnusucreatActionPerformed
        // TODO add your handling code here:
        adicionar();
    }//GEN-LAST:event_btnusucreatActionPerformed

    private void btnusuupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnusuupdateActionPerformed
        // TODO add your handling code here:
        alterar();
    }//GEN-LAST:event_btnusuupdateActionPerformed

    private void btnusudeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnusudeleteActionPerformed
        // TODO add your handling code here:
        deletar();
    }//GEN-LAST:event_btnusudeleteActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnusucreat;
    private javax.swing.JButton btnusudelete;
    private javax.swing.JButton btnusuread;
    private javax.swing.JButton btnusuupdate;
    private javax.swing.JComboBox<String> cbousuperfil;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JFormattedTextField txtusufone;
    private javax.swing.JTextField txtusuid;
    private javax.swing.JTextField txtusunome;
    private javax.swing.JTextField txtususenha;
    private javax.swing.JTextField txtusuusu;
    // End of variables declaration//GEN-END:variables
}
